
export enum StudyMethodology {
  QUANTITATIVE = 'كمي',
  QUALITATIVE = 'نوعي',
  MIXED = 'مختلط'
}

export enum VariableRole {
  INDEPENDENT = 'مستقل',
  DEPENDENT = 'تابع',
  MEDIATOR = 'وسيط',
  MODERATOR = 'معدل'
}

export interface Variable {
  name: string;
  role: VariableRole;
}

export interface Relationship {
  source: string;
  target: string;
  type: string; // Positive, Negative, etc.
  significance: string;
  hypothesis?: string;
}

export interface Study {
  id: string;
  title: string;
  authors: string;
  year: string;
  source: string;
  abstract: string;
  methodology: StudyMethodology;
  design: string;
  sampleSize: string;
  sampleCharacteristics: string;
  variables: Variable[];
  results: string;
  gap: string;
  similarities: string;
  differences: string;
  relationships: Relationship[];
  hypotheses: string[];
}

export interface UserDissertationContext {
  title: string;
  methodology: string;
  independentVariable: string;
  dependentVariable: string;
  mediatingVariable: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
