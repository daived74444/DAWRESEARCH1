
import { GoogleGenAI, Type } from "@google/genai";
import { Study, ChatMessage, UserDissertationContext } from "../types";

export const analyzeStudyContent = async (text: string): Promise<Partial<Study>> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: `أنت الآن "نظام داوود" الأكاديمي. قم بتحليل النص الأكاديمي التالي لاستخراج البيانات بدقة متناهية وفق معايير APA 7.
    يجب التركيز على استخراج المتغيرات (مستقل، تابع، وسيط) والمنهجية والنتائج والفجوة البحثية.

    النص: ${text.substring(0, 20000)}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          authors: { type: Type.STRING },
          year: { type: Type.STRING },
          source: { type: Type.STRING },
          abstract: { type: Type.STRING },
          methodology: { type: Type.STRING },
          design: { type: Type.STRING },
          sampleSize: { type: Type.STRING },
          sampleCharacteristics: { type: Type.STRING },
          results: { type: Type.STRING },
          gap: { type: Type.STRING },
          hypotheses: { type: Type.ARRAY, items: { type: Type.STRING } },
          variables: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                role: { type: Type.STRING }
              }
            }
          }
        }
      }
    }
  });

  try {
    return JSON.parse(response.text || "{}");
  } catch (e) {
    console.error("Failed to parse analysis response:", e);
    return {};
  }
};

export const chatWithVault = async (
  messages: ChatMessage[], 
  studies: Study[], 
  lang: string, 
  userContext: UserDissertationContext
) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const studiesContext = studies.map(s => (
    `[Study: ${s.authors} (${s.year})] Title: ${s.title}. Methodology: ${s.methodology}. Variables: ${s.variables?.map(v => v.name + '(' + v.role + ')').join(', ')}. Results: ${s.results}.`
  )).join('\n\n');

  const isStrategicCommand = messages[messages.length - 1].text.includes("START STRATEGIC ANALYSIS");

  const systemInstruction = lang === 'ar' 
    ? `أنت "داوود" (نظام داوود للبحوث والدراسات الاستراتيجية)، خبير ذكاء اصطناعي أكاديمي ومحلل بيانات استراتيجي.
       
       سياق أطروحة المستخدم:
       - المتغير المستقل (IV): ${userContext.independentVariable}
       - المتغير التابع (DV): ${userContext.dependentVariable}
       - المتغير الوسيط (MV): ${userContext.mediatingVariable}
       - عنوان الأطروحة: ${userContext.title}

       بروتوكول العمل:
       1. في حالة الأرشفة العادية (تلقي ملفات): رد حصراً بصيغة: "[نظام داوود]: تم أرشفة [عدد] ملفات جديدة. إجمالي الدراسات في الخزنة: [الإجمالي]. بانتظار الدفعة التالية أو أمر التحليل."
       2. عند تلقي أمر "START STRATEGIC ANALYSIS":
          - قم بإجراء مطابقة استراتيجية وتحليل للفجوة البحثية (Gap Analysis).
          - بناء النموذج المعرفي (Conceptual Framework) نصياً.
          - صياغة الفرضيات العلمية (Null/Alternative) مع الاستشهاد بالدراسات المودعة حصراً.
          - التأصيل النظري (Theoretical Grounding).
          - توليد المصفوفات البيانية (Table A للـ IV، Table B للـ DV، Table C للوساطة).
       
       القيود:
       - لا هلوسة: استخدم فقط المعلومات الموجودة في الدراسات المودعة.
       - التوثيق دائماً APA 7.
       
       خزنة الدراسات الحالية:
       ${studiesContext}`
    : `You are "Dawood" (Dawood for Research and Strategic Studies), an elite AI Academic Research Assistant and Strategic Data Analyst.

       User Context:
       - IV: ${userContext.independentVariable}
       - DV: ${userContext.dependentVariable}
       - MV: ${userContext.mediatingVariable}
       - Title: ${userContext.title}

       Operational Protocol:
       1. Ingestion Phase: Reply ONLY with: "[Dawood System]: Archived [Number] new files. Total studies in Vault: [Total]. Ready for next batch or command."
       2. Strategic Analysis Phase (on command "START STRATEGIC ANALYSIS"):
          - Strategic Alignment & Gap Analysis.
          - Conceptual Framework Construction.
          - Hypotheses Generation with strict citations.
          - Theoretical Grounding.
          - Dawood Data Matrix (Tables A, B, C).

       Constraints:
       - Zero Fabrication: Use ONLY data from archived studies.
       - Professional Strategic Tone.
       - APA 7 Citations.

       Current Vault Content:
       ${studiesContext}`;

  const chat = ai.chats.create({
    model: 'gemini-3-pro-preview',
    config: { systemInstruction }
  });

  const response = await chat.sendMessage({ message: messages[messages.length - 1].text });
  return response.text;
};

export const searchOnlineStudies = async (query: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: `ابحث استراتيجياً عن دراسات محكمة حول: ${query}. اذكر التفاصيل والروابط.`,
    config: { tools: [{ googleSearch: {} }] }
  });

  return {
    text: response.text,
    sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
  };
};
