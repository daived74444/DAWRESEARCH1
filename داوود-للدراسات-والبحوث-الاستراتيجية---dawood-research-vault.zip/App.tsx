
import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import StudyForm from './components/StudyForm';
import ChatView from './components/ChatView';
import AnalysisPanel from './components/AnalysisPanel';
import { Study, StudyMethodology, VariableRole, UserDissertationContext } from './types';
import { translations, Language } from './translations';
import { Plus, Database, Search, Download, Trash2, Edit, Sparkles, MessageSquare, Loader2, LayoutGrid, Filter, Languages, TrendingUp, Anchor, Settings } from 'lucide-react';
import { searchOnlineStudies } from './services/geminiService';

const App: React.FC = () => {
  const [lang, setLang] = useState<Language>('ar');
  const t = translations[lang];
  
  const [activeTab, setActiveTab] = useState('dashboard');
  const [studies, setStudies] = useState<Study[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingStudy, setEditingStudy] = useState<Study | null>(null);
  const [activeStudy, setActiveStudy] = useState<Study | null>(null);
  const [isAnalysisOpen, setIsAnalysisOpen] = useState(true);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  
  const [userContext, setUserContext] = useState<UserDissertationContext>({
    title: '',
    methodology: '',
    independentVariable: '',
    dependentVariable: '',
    mediatingVariable: ''
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<{text: string, sources: any[]}>({ text: '', sources: [] });
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('research_vault_v3');
    const savedContext = localStorage.getItem('research_vault_context');
    if (saved) {
      const parsed = JSON.parse(saved);
      setStudies(parsed);
      if (parsed.length > 0) setActiveStudy(parsed[0]);
    }
    if (savedContext) {
      setUserContext(JSON.parse(savedContext));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('research_vault_v3', JSON.stringify(studies));
  }, [studies]);

  useEffect(() => {
    localStorage.setItem('research_vault_context', JSON.stringify(userContext));
  }, [userContext]);

  const toggleLanguage = () => {
    setLang(prev => prev === 'ar' ? 'en' : 'ar');
  };

  const handleAddStudy = (study: Study) => {
    if (editingStudy) {
      setStudies(studies.map(s => s.id === study.id ? study : s));
      setEditingStudy(null);
    } else {
      setStudies([...studies, study]);
    }
    setActiveStudy(study);
    setIsFormOpen(false);
  };

  const deleteStudy = (id: string) => {
    if (confirm(lang === 'ar' ? 'هل أنت متأكد من حذف هذه الأطروحة؟' : 'Are you sure you want to delete this thesis?')) {
      const updated = studies.filter(s => s.id !== id);
      setStudies(updated);
      if (activeStudy?.id === id) setActiveStudy(updated[0] || null);
    }
  };

  return (
    <div className={`min-h-screen flex bg-[#fdfdfd] overflow-hidden ${lang === 'ar' ? 'font-["Tajawal"]' : 'font-sans'}`} dir={lang === 'ar' ? 'rtl' : 'ltr'}>
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} studies={studies} lang={lang} />
      <AnalysisPanel activeStudy={activeStudy} isOpen={isAnalysisOpen} setIsOpen={setIsAnalysisOpen} lang={lang} />

      <main className={`flex-1 transition-all duration-700 py-10 px-12 overflow-y-auto h-screen ${isAnalysisOpen ? (lang === 'ar' ? 'ml-80' : 'mr-80') : 'mx-0'} ${lang === 'ar' ? 'mr-72' : 'ml-72'}`}>
        <header className="flex justify-between items-start mb-16">
          <div className="animate-fade-in">
            <div className="flex items-center gap-3 mb-3">
               <div className="px-4 py-1.5 bg-slate-900 text-amber-500 text-[10px] font-black rounded-full border border-slate-800 uppercase tracking-[0.2em] shadow-xl">Dawood Strategic Intel</div>
               <span className="text-slate-200 text-xs">•</span>
               <div className="text-slate-400 text-[10px] font-bold uppercase tracking-widest flex items-center gap-2">
                 <TrendingUp size={12} /> {lang === 'ar' ? 'منظومة داوود' : 'Dawood System'}
               </div>
            </div>
            <h1 className="text-5xl font-black text-slate-900 academic-title leading-tight">
              {activeTab === 'dashboard' && t.dashboard}
              {activeTab === 'studies' && t.vault}
              {activeTab === 'chat' && t.smartChat}
              {activeTab === 'search' && t.search}
              {activeTab === 'reports' && t.reports}
            </h1>
          </div>
          
          <div className="flex items-center gap-4 animate-fade-in">
            <button 
              onClick={() => setIsSettingsOpen(true)}
              className="flex items-center gap-2 px-5 py-3.5 bg-white border border-slate-100 rounded-[1.25rem] text-slate-600 hover:text-slate-900 shadow-lg transition-all"
            >
              <Settings size={20} className="text-amber-500" />
            </button>
            <button 
              onClick={toggleLanguage}
              className="flex items-center gap-2 px-5 py-3.5 bg-white border border-slate-100 rounded-[1.25rem] text-slate-900 hover:shadow-2xl transition-all text-xs font-black shadow-lg"
            >
              <Languages size={18} className="text-amber-500" />
              <span>{t.langToggle}</span>
            </button>
            <button
              onClick={() => { setEditingStudy(null); setIsFormOpen(true); }}
              className="flex items-center gap-3 px-10 py-4 bg-slate-900 text-amber-500 rounded-[1.25rem] hover:bg-black shadow-[0_20px_40px_rgba(15,23,42,0.2)] transition-all font-black"
            >
              <Plus size={20} />
              <span className="text-sm">{t.addStudy}</span>
            </button>
          </div>
        </header>

        {activeTab === 'dashboard' && (
          <div className="space-y-12 animate-fade-in">
             <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                <div className="bg-white p-10 rounded-[3rem] border border-slate-50 shadow-sm flex flex-col justify-between h-56 relative overflow-hidden group">
                  <div className={`absolute ${lang === 'ar' ? '-right-6' : '-left-6'} -top-6 w-32 h-32 bg-blue-50/30 rounded-full group-hover:scale-125 transition-transform duration-700`}></div>
                  <Database size={40} className="text-slate-900 relative z-10" />
                  <div className="relative z-10">
                    <p className="text-slate-400 text-[11px] font-black uppercase tracking-[0.2em]">{t.totalDocuments}</p>
                    <h3 className="text-5xl font-black text-slate-900 mt-2">{studies.length} <span className="text-base font-bold text-slate-300 academic-title">{lang === 'ar' ? 'دراسة' : 'studies'}</span></h3>
                  </div>
                </div>
                <div className="bg-white p-10 rounded-[3rem] border border-slate-50 shadow-sm flex flex-col justify-between h-56 relative overflow-hidden group">
                  <div className={`absolute ${lang === 'ar' ? '-right-6' : '-left-6'} -top-6 w-32 h-32 bg-emerald-50/30 rounded-full group-hover:scale-125 transition-transform duration-700`}></div>
                  <Sparkles size={40} className="text-emerald-600 relative z-10" />
                  <div>
                    <p className="text-slate-400 text-[11px] font-black uppercase tracking-[0.2em]">{t.variableCoverage}</p>
                    <h3 className="text-5xl font-black text-slate-900 mt-2">
                      {studies.reduce((acc, s) => acc + (s.variables?.length || 0), 0)} 
                      <span className="text-base font-bold text-slate-300 academic-title"> {lang === 'ar' ? 'ارتباط' : 'links'}</span>
                    </h3>
                  </div>
                </div>
                <div className="bg-slate-900 p-10 rounded-[3rem] shadow-2xl flex flex-col justify-between h-56 relative overflow-hidden group">
                  <div className={`absolute ${lang === 'ar' ? '-right-6' : '-left-6'} -top-6 w-32 h-32 bg-white/5 rounded-full group-hover:scale-125 transition-transform duration-700`}></div>
                  <Anchor size={40} className="text-amber-500 relative z-10" />
                  <div>
                    <p className="text-slate-400 text-[11px] font-black uppercase tracking-[0.2em]">{lang === 'ar' ? 'حالة النظام' : 'System Status'}</p>
                    <h3 className="text-3xl font-black text-white mt-2 academic-title">{t.activeStatus}</h3>
                  </div>
                </div>
             </div>

             <div className="bg-white p-12 rounded-[3.5rem] border border-slate-100 shadow-xl">
                <div className="flex justify-between items-center mb-10">
                  <h3 className="text-2xl font-black text-slate-900 academic-title">{t.foundHypotheses}</h3>
                  <button onClick={() => setActiveTab('reports')} className="text-[11px] font-black text-amber-600 uppercase tracking-[0.2em] hover:text-amber-800 transition-colors">
                    {lang === 'ar' ? 'عرض المصفوفة البيانية' : 'View Data Matrix'}
                  </button>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {studies.slice(-4).flatMap(s => s.hypotheses?.slice(0, 1) || []).map((h, i) => (
                    <div key={i} className="p-6 bg-slate-50 rounded-3xl border border-slate-100 flex items-start gap-4 hover:shadow-lg transition-all">
                      <div className="w-10 h-10 bg-white rounded-xl shadow-sm flex items-center justify-center shrink-0 text-amber-600"><TrendingUp size={20} /></div>
                      <p className="text-sm font-bold text-slate-700 academic-text">"{h}"</p>
                    </div>
                  ))}
                  {studies.length === 0 && <div className="col-span-2 text-center py-20 text-slate-300 font-black uppercase tracking-widest">{lang === 'ar' ? 'بانتظار إيداع الملفات في الخزنة' : 'Waiting for files to be deposited'}</div>}
                </div>
             </div>
          </div>
        )}

        {activeTab === 'chat' && <ChatView studies={studies} onStudySelect={setActiveStudy} lang={lang} userContext={userContext} />}
        
        {activeTab === 'reports' && (
          <div className="space-y-16 pb-32 animate-fade-in">
             <div className="bg-white rounded-[4rem] border border-slate-200 shadow-2xl overflow-hidden">
                <div className="p-12 border-b border-slate-100 flex justify-between items-center bg-slate-50/30">
                   <div>
                      <h3 className="text-3xl font-black text-slate-900 academic-title">{lang === 'ar' ? 'المصفوفة الاستراتيجية للدراسات (APA 7)' : 'Strategic Study Matrix (APA 7)'}</h3>
                      <p className="text-[10px] text-slate-400 mt-2 uppercase tracking-[0.3em] font-black">Strategic Research Documentation</p>
                   </div>
                   <button className="flex items-center gap-3 px-8 py-4 bg-slate-900 text-amber-500 rounded-[1.5rem] font-black shadow-2xl hover:bg-black transition-all">
                      <Download size={20} /> {t.exportWord}
                   </button>
                </div>
                <div className="overflow-x-auto">
                   <table className={`w-full text-[12px] academic-table whitespace-nowrap ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
                      <thead>
                        <tr>
                          <th>{lang === 'ar' ? 'المؤلف والسنة' : 'Author & Year'}</th>
                          <th>{lang === 'ar' ? 'المتغيرات' : 'Variables'}</th>
                          <th>{lang === 'ar' ? 'المنهجية' : 'Methodology'}</th>
                          <th>{lang === 'ar' ? 'أبرز النتائج' : 'Main Results'}</th>
                          <th>{lang === 'ar' ? 'الصلة بالأطروحة' : 'Relevance'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {studies.map(s => (
                          <tr key={s.id} className="hover:bg-slate-50/50 transition-colors">
                            <td className="font-black text-slate-900 academic-title">{s.authors} ({s.year})</td>
                            <td>
                              <div className="flex gap-1.5">
                                 {s.variables?.map((v, idx) => (
                                   <span key={idx} className={`px-2 py-0.5 rounded-lg text-[10px] font-bold ${v.role === VariableRole.INDEPENDENT ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600'}`}>{v.name}</span>
                                 ))}
                              </div>
                            </td>
                            <td className="text-slate-500 font-medium italic">{s.methodology}</td>
                            <td className="max-w-xs overflow-hidden truncate font-bold text-slate-800">{s.results.substring(0, 60)}...</td>
                            <td className="text-amber-800 font-black">{lang === 'ar' ? 'دعم استراتيجي' : 'Strategic Support'}</td>
                          </tr>
                        ))}
                      </tbody>
                   </table>
                </div>
             </div>
          </div>
        )}

        {activeTab === 'studies' && (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-10 animate-fade-in">
             {studies.map(study => (
               <div 
                 key={study.id} 
                 onClick={() => setActiveStudy(study)}
                 className={`bg-white p-10 rounded-[3.5rem] border transition-all duration-500 cursor-pointer relative overflow-hidden shadow-sm hover:shadow-2xl ${activeStudy?.id === study.id ? 'border-amber-500 ring-[12px] ring-amber-50' : 'border-slate-50 hover:border-slate-200'}`}
               >
                  <div className="flex justify-between items-start mb-8">
                    <div className="w-14 h-14 bg-slate-900 rounded-[1.5rem] flex items-center justify-center text-amber-500 font-black text-lg shadow-xl">
                      {study.year.slice(-2)}'
                    </div>
                    <div className="flex gap-4">
                       <button onClick={(e) => { e.stopPropagation(); deleteStudy(study.id); }} className="text-slate-300 hover:text-red-500 transition-all hover:scale-125"><Trash2 size={22} /></button>
                       <button onClick={(e) => { e.stopPropagation(); setEditingStudy(study); setIsFormOpen(true); }} className="text-slate-300 hover:text-blue-500 transition-all hover:scale-125"><Edit size={22} /></button>
                    </div>
                  </div>
                  <h3 className="font-black text-slate-900 text-lg mb-4 leading-[1.6] academic-title line-clamp-2">{study.title}</h3>
                  <p className="text-[11px] text-slate-400 mb-8 font-black uppercase tracking-widest">{study.authors}</p>
                  <div className="flex gap-2 flex-wrap">
                    {study.variables?.slice(0, 3).map((v, i) => (
                      <span key={i} className={`px-4 py-1.5 rounded-full text-[10px] font-black border ${v.role === VariableRole.INDEPENDENT ? 'bg-amber-50 border-amber-100 text-amber-700' : 'bg-slate-50 border-slate-100 text-slate-500'}`}>{v.name}</span>
                    ))}
                  </div>
               </div>
             ))}
          </div>
        )}

        {isSettingsOpen && (
          <div className="fixed inset-0 bg-slate-900/95 backdrop-blur-2xl z-[110] flex items-center justify-center p-12 animate-fade-in">
            <div className="w-full max-w-2xl bg-white shadow-2xl rounded-[3rem] overflow-hidden p-12 space-y-10 border border-slate-100">
              <div className="flex justify-between items-center">
                <h3 className="text-2xl font-black text-slate-900 academic-title">{t.contextSettings}</h3>
                <button onClick={() => setIsSettingsOpen(false)} className="text-slate-400 hover:text-slate-900 font-bold text-2xl">&times;</button>
              </div>
              <div className="space-y-8">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t.dissertationTitle}</label>
                  <input 
                    value={userContext.title} 
                    onChange={e => setUserContext({...userContext, title: e.target.value})}
                    placeholder="[INSERT TITLE]"
                    className="w-full p-5 rounded-2xl border border-slate-100 outline-none focus:border-slate-900 bg-slate-50 font-bold"
                  />
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t.proposedMethodology}</label>
                    <input 
                      value={userContext.methodology} 
                      onChange={e => setUserContext({...userContext, methodology: e.target.value})}
                      placeholder="[INSERT METHODOLOGY]"
                      className="w-full p-5 rounded-2xl border border-slate-100 outline-none focus:border-slate-900 bg-slate-50"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t.iv}</label>
                    <input 
                      value={userContext.independentVariable} 
                      onChange={e => setUserContext({...userContext, independentVariable: e.target.value})}
                      placeholder="[INSERT INDEPENDENT VARIABLE]"
                      className="w-full p-5 rounded-2xl border border-slate-100 outline-none focus:border-slate-900 bg-slate-50"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t.dv}</label>
                    <input 
                      value={userContext.dependentVariable} 
                      onChange={e => setUserContext({...userContext, dependentVariable: e.target.value})}
                      placeholder="[INSERT DEPENDENT VARIABLE]"
                      className="w-full p-5 rounded-2xl border border-slate-100 outline-none focus:border-slate-900 bg-slate-50"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t.mv}</label>
                    <input 
                      value={userContext.mediatingVariable} 
                      onChange={e => setUserContext({...userContext, mediatingVariable: e.target.value})}
                      placeholder="[INSERT MEDIATING VARIABLE]"
                      className="w-full p-5 rounded-2xl border border-slate-100 outline-none focus:border-slate-900 bg-slate-50"
                    />
                  </div>
                </div>
              </div>
              <button 
                onClick={() => setIsSettingsOpen(false)}
                className="w-full py-5 bg-slate-900 text-amber-500 rounded-3xl font-black shadow-2xl hover:bg-black transition-all"
              >
                {t.updateContext}
              </button>
            </div>
          </div>
        )}

        {isFormOpen && (
          <div className="fixed inset-0 bg-slate-900/90 backdrop-blur-3xl z-[100] flex items-center justify-center p-12 animate-fade-in">
            <div className="w-full max-w-6xl shadow-2xl rounded-[4rem] overflow-hidden border border-white/10">
              <StudyForm 
                onCancel={() => { setIsFormOpen(false); setEditingStudy(null); }} 
                onSubmit={handleAddStudy}
                initialData={editingStudy}
                lang={lang}
              />
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
