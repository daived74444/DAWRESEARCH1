
import React, { useState } from 'react';
import { Study, StudyMethodology, VariableRole } from '../types';
import { Language, translations } from '../translations';
import { analyzeStudyContent } from '../services/geminiService';
import { Loader2, Sparkles, Plus, Trash2 } from 'lucide-react';

interface StudyFormProps {
  onSubmit: (study: Study) => void;
  onCancel: () => void;
  initialData?: Study | null;
  lang: Language;
}

const StudyForm: React.FC<StudyFormProps> = ({ onSubmit, onCancel, initialData, lang }) => {
  const t = translations[lang];
  const [formData, setFormData] = useState<Study>(initialData || {
    id: Math.random().toString(36).substr(2, 9),
    title: '',
    authors: '',
    year: '',
    source: '',
    abstract: '',
    methodology: StudyMethodology.QUANTITATIVE,
    design: '',
    sampleSize: '',
    sampleCharacteristics: '',
    variables: [],
    results: '',
    gap: '',
    similarities: '',
    differences: '',
    relationships: [],
    hypotheses: []
  });

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [rawText, setRawText] = useState('');

  const handleAIAnalysis = async () => {
    if (!rawText.trim()) return;
    setIsAnalyzing(true);
    try {
      const extracted = await analyzeStudyContent(rawText);
      setFormData(prev => ({
        ...prev,
        ...extracted,
        variables: extracted.variables || prev.variables,
        relationships: extracted.relationships || prev.relationships,
        hypotheses: extracted.hypotheses || prev.hypotheses
      }));
    } finally {
      setIsAnalyzing(false);
    }
  };

  const addVariable = () => {
    setFormData(prev => ({
      ...prev,
      variables: [...(prev.variables || []), { name: '', role: VariableRole.INDEPENDENT }]
    }));
  };

  const removeVariable = (index: number) => {
    setFormData(prev => ({
      ...prev,
      variables: prev.variables.filter((_, i) => i !== index)
    }));
  };

  const updateVariable = (index: number, field: string, value: string) => {
    const newVars = [...formData.variables];
    newVars[index] = { ...newVars[index], [field as keyof typeof newVars[0]]: value };
    setFormData({ ...formData, variables: newVars });
  };

  return (
    <div className={`bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden ${lang === 'en' ? 'text-left' : 'text-right'}`}>
      <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
        <h2 className="text-xl font-bold text-slate-800">{lang === 'ar' ? 'تحليل دراسة سابقة' : 'Study Analysis'}</h2>
        <div className="space-x-2 flex gap-2">
          <button onClick={onCancel} className="px-4 py-2 text-slate-500 hover:text-slate-700">{t.cancel}</button>
          <button 
            onClick={() => onSubmit(formData)}
            className="px-6 py-2 bg-slate-900 text-amber-500 rounded-lg hover:bg-black font-semibold shadow-sm transition-all"
          >
            {t.save}
          </button>
        </div>
      </div>

      <div className="p-8 space-y-8 max-h-[75vh] overflow-y-auto custom-scrollbar">
        {/* AI Assist Section */}
        <div className="bg-amber-50/50 border border-amber-100 p-6 rounded-3xl space-y-4">
          <div className="flex items-center gap-2 text-amber-700 font-bold">
            <Sparkles size={18} />
            <span>{lang === 'ar' ? 'مساعد الاستخلاص الذكي' : 'Smart Extraction Assistant'}</span>
          </div>
          <p className="text-xs text-slate-500">
            {lang === 'ar' ? 'ألصق نص الدراسة أو الملخص هنا لاستخراج البيانات تلقائياً.' : 'Paste study text or abstract here to extract data automatically.'}
          </p>
          <textarea
            value={rawText}
            onChange={(e) => setRawText(e.target.value)}
            className="w-full h-32 p-4 rounded-2xl border border-amber-100 focus:ring-2 focus:ring-amber-500 outline-none text-sm bg-white"
            placeholder={lang === 'ar' ? 'انسخ النص هنا...' : 'Paste text here...'}
          />
          <button
            onClick={handleAIAnalysis}
            disabled={isAnalyzing || !rawText}
            className="w-full flex items-center justify-center gap-2 py-3 bg-slate-900 text-amber-500 rounded-2xl hover:bg-black disabled:opacity-50 transition-all font-bold"
          >
            {isAnalyzing ? <Loader2 className="animate-spin" size={18} /> : <Sparkles size={18} />}
            {isAnalyzing ? (lang === 'ar' ? 'جاري التحليل...' : 'Analyzing...') : (lang === 'ar' ? 'استخلاص البيانات بواسطة Gemini' : 'Extract Data via Gemini')}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">{lang === 'ar' ? 'عنوان الدراسة' : 'Study Title'}</label>
            <input
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full p-4 rounded-2xl border border-slate-100 outline-none focus:border-slate-900 bg-slate-50/50"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t.authors}</label>
            <input
              value={formData.authors}
              onChange={(e) => setFormData({ ...formData, authors: e.target.value })}
              className="w-full p-4 rounded-2xl border border-slate-100 outline-none focus:border-slate-900 bg-slate-50/50"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t.year}</label>
            <input
              value={formData.year}
              onChange={(e) => setFormData({ ...formData, year: e.target.value })}
              className="w-full p-4 rounded-2xl border border-slate-100 outline-none focus:border-slate-900 bg-slate-50/50"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t.source}</label>
            <input
              value={formData.source}
              onChange={(e) => setFormData({ ...formData, source: e.target.value })}
              className="w-full p-4 rounded-2xl border border-slate-100 outline-none focus:border-slate-900 bg-slate-50/50"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t.abstract}</label>
          <textarea
            value={formData.abstract}
            onChange={(e) => setFormData({ ...formData, abstract: e.target.value })}
            className="w-full h-24 p-4 rounded-2xl border border-slate-100 outline-none focus:border-slate-900 bg-slate-50/50"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t.methodology}</label>
            <select
              value={formData.methodology}
              onChange={(e) => setFormData({ ...formData, methodology: e.target.value as StudyMethodology })}
              className="w-full p-4 rounded-2xl border border-slate-100 outline-none focus:border-slate-900 bg-white"
            >
              {Object.values(StudyMethodology).map(m => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">{lang === 'ar' ? 'حجم العينة' : 'Sample Size'}</label>
            <input
              value={formData.sampleSize}
              onChange={(e) => setFormData({ ...formData, sampleSize: e.target.value })}
              className="w-full p-4 rounded-2xl border border-slate-100 outline-none focus:border-slate-900 bg-slate-50/50"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">{lang === 'ar' ? 'خصائص العينة' : 'Sample Characteristics'}</label>
            <input
              value={formData.sampleCharacteristics}
              onChange={(e) => setFormData({ ...formData, sampleCharacteristics: e.target.value })}
              className="w-full p-4 rounded-2xl border border-slate-100 outline-none focus:border-slate-900 bg-slate-50/50"
            />
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t.variableMap}</label>
            <button
              onClick={addVariable}
              className="text-xs flex items-center gap-1 text-amber-600 hover:text-amber-700 font-bold"
            >
              <Plus size={14} /> {lang === 'ar' ? 'إضافة متغير' : 'Add Variable'}
            </button>
          </div>
          <div className="space-y-3">
            {formData.variables?.map((v, idx) => (
              <div key={idx} className="flex gap-3 items-center">
                <input
                  value={v.name}
                  onChange={(e) => updateVariable(idx, 'name', e.target.value)}
                  className="flex-1 p-3 rounded-xl border border-slate-100 outline-none text-sm bg-slate-50/50"
                  placeholder={lang === 'ar' ? 'اسم المتغير' : 'Variable Name'}
                />
                <select
                  value={v.role}
                  onChange={(e) => updateVariable(idx, 'role', e.target.value)}
                  className="w-32 p-3 rounded-xl border border-slate-100 outline-none text-sm bg-white"
                >
                  {Object.values(VariableRole).map(r => <option key={r} value={r}>{r}</option>)}
                </select>
                <button onClick={() => removeVariable(idx)} className="text-red-400 hover:text-red-600 transition-colors">
                  <Trash2 size={18} />
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t.results}</label>
            <textarea
              value={formData.results}
              onChange={(e) => setFormData({ ...formData, results: e.target.value })}
              className="w-full h-32 p-4 rounded-2xl border border-slate-100 outline-none focus:border-slate-900 bg-slate-50/50"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t.gap}</label>
            <textarea
              value={formData.gap}
              onChange={(e) => setFormData({ ...formData, gap: e.target.value })}
              className="w-full h-32 p-4 rounded-2xl border border-slate-100 outline-none focus:border-slate-900 bg-slate-50/50"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudyForm;
