
import React from 'react';
import { LayoutDashboard, Database, Search, FileText, MessageSquare, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { Study } from '../types';
import { translations, Language } from '../translations';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  studies: Study[];
  lang: Language;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, studies, lang }) => {
  const t = translations[lang];
  const menuItems = [
    { id: 'dashboard', label: t.dashboard, icon: LayoutDashboard },
    { id: 'studies', label: t.vault, icon: Database },
    { id: 'chat', label: t.smartChat, icon: MessageSquare },
    { id: 'search', label: t.search, icon: Search },
    { id: 'reports', label: t.reports, icon: FileText },
  ];

  return (
    <div className={`w-72 h-screen bg-white border-slate-200 flex flex-col fixed top-0 z-20 shadow-xl ${lang === 'ar' ? 'right-0 border-l' : 'left-0 border-r'}`}>
      <div className="p-8 border-b border-slate-50 flex flex-col gap-1">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-slate-900 rounded-2xl flex items-center justify-center text-amber-500 font-bold text-2xl shadow-xl shadow-slate-200 border border-slate-800">
            {lang === 'ar' ? 'خ' : 'V'}
          </div>
          <div>
            <h1 className="text-xl font-black text-slate-900 leading-tight academic-title">{t.appName}</h1>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{t.appSubName}</p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar">
        <div className="px-4 py-6 space-y-1">
          <p className="px-4 mb-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            {lang === 'ar' ? 'القائمة الرئيسية' : 'Main Menu'}
          </p>
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl transition-all duration-300 ${
                activeTab === item.id
                  ? 'bg-slate-900 text-white font-bold shadow-lg shadow-slate-200'
                  : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <item.icon size={18} className={activeTab === item.id ? 'text-amber-500' : ''} />
              <span className="text-sm">{item.label}</span>
            </button>
          ))}
        </div>

        <div className="px-4 py-6">
          <div className="flex items-center justify-between px-4 mb-4">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
               {lang === 'ar' ? 'حالة الخزنة' : 'Vault Status'}
            </p>
            <span className="bg-amber-100 text-amber-700 text-[9px] font-bold px-2 py-0.5 rounded-full">PRO</span>
          </div>
          <div className="space-y-3">
            {studies.slice(0, 5).map(s => (
              <div key={s.id} onClick={() => setActiveTab('studies')} className="group p-3 rounded-xl border border-slate-50 hover:border-slate-200 hover:bg-slate-50 transition-all cursor-pointer">
                <div className="flex items-start gap-3">
                  <div className="mt-1">
                    <CheckCircle2 size={14} className="text-emerald-500" />
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <h4 className="text-[11px] font-bold text-slate-700 truncate">{s.title}</h4>
                    <p className="text-[9px] text-slate-400 mt-0.5">{s.year} • {s.authors.split(/[،,]/)[0]}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="p-6 border-t border-slate-50 bg-slate-50/50">
        <div className="flex items-center gap-3 p-3 bg-white rounded-2xl border border-slate-200 shadow-sm">
          <div className="w-8 h-8 rounded-full bg-slate-900 flex items-center justify-center text-amber-500">
            <ShieldCheck size={16} />
          </div>
          <div className="flex-1 overflow-hidden">
             <p className="text-[10px] font-bold text-slate-800 truncate">
               {lang === 'ar' ? 'داوود للبحوث والدراسات' : 'Dawood Research & Studies'}
             </p>
             <p className="text-[8px] text-slate-400">
               {lang === 'ar' ? 'التميز في التحليل الاستراتيجي' : 'Strategic Analysis Excellence'}
             </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
