
import React from 'react';
import { Study, VariableRole } from '../types';
import { Language, translations } from '../translations';
import { Info, Target, GitBranch, Layers, ChevronLeft, ChevronRight } from 'lucide-react';

interface AnalysisPanelProps {
  activeStudy: Study | null;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  lang: Language;
}

const AnalysisPanel: React.FC<AnalysisPanelProps> = ({ activeStudy, isOpen, setIsOpen, lang }) => {
  const t = translations[lang];
  
  if (!isOpen) return (
    <button 
      onClick={() => setIsOpen(true)}
      className={`fixed top-1/2 -translate-y-1/2 bg-white border border-slate-200 p-2 shadow-xl z-20 hover:bg-slate-50 ${lang === 'ar' ? 'left-0 rounded-r-xl' : 'right-0 rounded-l-xl'}`}
    >
      {lang === 'ar' ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
    </button>
  );

  return (
    <div className={`w-80 h-screen glass-panel fixed top-0 z-20 flex flex-col shadow-2xl animate-fade-in ${lang === 'ar' ? 'left-0' : 'right-0'}`}>
      <div className="p-6 border-b border-slate-100 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Layers size={18} className="text-amber-600" />
          <h3 className="font-bold text-slate-800 text-sm">{t.analysisCard}</h3>
        </div>
        <button onClick={() => setIsOpen(false)} className="text-slate-400 hover:text-slate-600">
          {lang === 'ar' ? <ChevronLeft size={20} /> : <ChevronRight size={20} />}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-8 custom-scrollbar">
        {!activeStudy ? (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
            <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-slate-300">
              <Info size={32} />
            </div>
            <p className="text-xs text-slate-400 px-8">
              {lang === 'ar' ? 'اختر دراسة من الخزنة لتظهر بيانات التحليل هنا' : 'Select a study to see the analysis card here'}
            </p>
          </div>
        ) : (
          <>
            <section className="space-y-3 text-right">
              <p className={`text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2 ${lang === 'en' ? 'flex-row-reverse' : ''}`}>
                <Target size={12} className="text-amber-500" /> {t.methodology}
              </p>
              <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
                <h4 className="text-sm font-bold text-slate-800 mb-1">{activeStudy.methodology}</h4>
                <p className="text-[10px] text-slate-500 leading-relaxed">{activeStudy.design}</p>
              </div>
            </section>

            <section className="space-y-3">
              <p className={`text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2 ${lang === 'en' ? 'flex-row-reverse' : ''}`}>
                <GitBranch size={12} className="text-blue-500" /> {t.variableMap}
              </p>
              <div className="space-y-2">
                {activeStudy.variables?.map((v, i) => (
                  <div key={i} className={`p-3 rounded-xl text-xs flex items-center justify-between border-slate-100 border ${
                    v.role === VariableRole.INDEPENDENT ? 'variable-tag-independent' :
                    v.role === VariableRole.DEPENDENT ? 'variable-tag-dependent' :
                    'variable-tag-mediator'
                  } ${lang === 'en' ? 'flex-row-reverse' : ''}`}>
                    <span className="font-bold">{v.name}</span>
                    <span className="text-[9px] opacity-60 font-medium uppercase">{v.role}</span>
                  </div>
                ))}
              </div>
            </section>

            <section className="space-y-3">
               <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t.coreResults}</p>
               <div className="p-4 bg-slate-900 text-white rounded-2xl text-[11px] leading-relaxed italic shadow-xl">
                 "{activeStudy.results.substring(0, 150)}..."
               </div>
            </section>

            <section className="space-y-3">
               <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t.researchGap}</p>
               <div className="p-4 bg-amber-50 text-amber-900 border border-amber-100 rounded-2xl text-[11px] leading-relaxed">
                 {activeStudy.gap}
               </div>
            </section>
          </>
        )}
      </div>
    </div>
  );
};

export default AnalysisPanel;
