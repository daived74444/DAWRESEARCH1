
import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, Loader2, BookOpen, Zap, Quote, PlayCircle } from 'lucide-react';
import { ChatMessage, Study, UserDissertationContext } from '../types';
import { Language, translations } from '../translations';
import { chatWithVault } from '../services/geminiService';

interface ChatViewProps {
  studies: Study[];
  onStudySelect?: (study: Study) => void;
  lang: Language;
  userContext: UserDissertationContext;
}

const ChatView: React.FC<ChatViewProps> = ({ studies, onStudySelect, lang, userContext }) => {
  const t = translations[lang];
  const [messages, setMessages] = useState<ChatMessage[]>([
    { 
      role: 'model', 
      text: lang === 'ar' 
        ? 'أنا نظام داوود للبحوث والدراسات الاستراتيجية. الخزنة جاهزة لاستقبال ملفاتك لبناء الإطار المعرفي لأطروحتك. يرجى رفع الوثائق للبدء.' 
        : 'I am Dawood for Research and Strategic Studies. The vault is ready to receive your files to build your conceptual framework. Please upload documents to begin.' 
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const handleSend = async (customText?: string) => {
    const textToSend = customText || input;
    if (!textToSend.trim() || isLoading) return;
    
    const userMsg: ChatMessage = { role: 'user', text: textToSend };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await chatWithVault([...messages, userMsg], studies, lang, userContext);
      setMessages(prev => [...prev, { role: 'model', text: response || (lang === 'ar' ? 'عذراً، فشل التحليل الاستراتيجي.' : 'Sorry, strategic analysis failed.') }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'model', text: lang === 'ar' ? 'عذراً، النظام يواجه عبئاً أكاديمياً حالياً.' : 'Sorry, the system is under heavy academic load.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={`flex flex-col h-[calc(100vh-140px)] bg-white/40 backdrop-blur-xl rounded-[2.5rem] border border-slate-200/40 shadow-2xl overflow-hidden animate-fade-in ${lang === 'en' ? 'text-left' : 'text-right'}`}>
      <div className={`px-10 py-6 border-b border-slate-100 bg-white/90 flex items-center justify-between ${lang === 'en' ? 'flex-row-reverse' : ''}`}>
        <div className={`flex items-center gap-5 ${lang === 'en' ? 'flex-row-reverse' : ''}`}>
          <div className="w-12 h-12 bg-slate-900 rounded-2xl flex items-center justify-center text-amber-500 shadow-2xl status-analyzing">
            <Zap size={24} />
          </div>
          <div className={lang === 'en' ? 'text-right' : 'text-left'}>
            <h2 className="text-base font-black text-slate-900 academic-title">{lang === 'ar' ? 'محراب داوود الاستراتيجي' : 'Dawood Strategic Chamber'}</h2>
            <div className={`flex items-center gap-2 mt-1 ${lang === 'en' ? 'flex-row-reverse' : ''}`}>
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]"></span>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                {lang === 'ar' ? 'خبير داوود متصل' : 'Dawood Expert Online'}
              </span>
            </div>
          </div>
        </div>
        <div className="flex gap-3">
           <button 
             onClick={() => handleSend("START STRATEGIC ANALYSIS")}
             className="px-4 py-2 bg-amber-500 text-slate-900 rounded-xl text-[10px] font-black flex items-center gap-2 hover:bg-amber-600 transition-all shadow-lg border-2 border-amber-600"
           >
             <PlayCircle size={16} /> {t.startFullAnalysis}
           </button>
           <div className="px-4 py-2 bg-slate-100 rounded-xl text-[10px] font-black text-slate-600 flex items-center gap-2 border border-slate-200/50">
             <BookOpen size={14} /> {studies.length} {lang === 'ar' ? 'دراسة مودعة' : 'archived studies'}
           </div>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-10 space-y-10 scroll-smooth custom-scrollbar">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? (lang === 'ar' ? 'justify-start' : 'justify-end') : (lang === 'ar' ? 'justify-end' : 'justify-start')}`}>
            <div className={`flex gap-5 max-w-[90%] ${msg.role === 'user' ? (lang === 'ar' ? 'flex-row' : 'flex-row-reverse') : (lang === 'ar' ? 'flex-row-reverse' : 'flex-row')}`}>
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-xl border-2 ${
                msg.role === 'user' ? 'bg-slate-900 text-amber-500 border-slate-800' : 'bg-white border-white text-slate-400'
              }`}>
                {msg.role === 'user' ? <User size={20} /> : <Bot size={20} />}
              </div>
              <div className={`p-8 text-[13px] leading-[1.8] shadow-sm transition-all hover:shadow-xl border ${
                msg.role === 'user' ? 'chat-bubble-user' : 'chat-bubble-model border-slate-100 academic-text'
              }`}>
                {msg.text}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className={`flex ${lang === 'en' ? 'justify-start' : 'justify-end'}`}>
            <div className={`flex gap-4 items-center text-slate-400 text-[11px] font-black tracking-widest ${lang === 'en' ? 'flex-row' : 'flex-row-reverse'}`}>
              <div className="flex gap-1.5">
                 <span className="w-2 h-2 bg-amber-500 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                 <span className="w-2 h-2 bg-amber-500 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                 <span className="w-2 h-2 bg-amber-500 rounded-full animate-bounce"></span>
              </div>
              {lang === 'ar' ? 'نظام داوود يعالج البيانات استراتيجياً...' : 'Dawood System processing strategic data...'}
            </div>
          </div>
        )}
      </div>

      <div className="p-10 bg-white/90 border-t border-slate-100/50">
        <div className="max-w-5xl mx-auto relative group">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder={lang === 'ar' ? 'اطلب صياغة النموذج المعرفي أو ابدأ التحليل الاستراتيجي...' : 'Request model building or start strategic analysis...'}
            className={`w-full p-6 rounded-[2rem] border-2 border-slate-100 outline-none focus:border-slate-900 focus:bg-white shadow-2xl transition-all bg-slate-50/50 text-slate-900 placeholder:text-slate-300 font-bold ${lang === 'ar' ? 'pr-16 pl-6' : 'pl-16 pr-6'}`}
          />
          <button
            onClick={() => handleSend()}
            disabled={!input.trim() || isLoading}
            className={`absolute top-1/2 -translate-y-1/2 w-14 h-14 bg-slate-900 text-amber-500 rounded-2xl flex items-center justify-center hover:bg-black hover:scale-110 active:scale-95 disabled:opacity-50 transition-all shadow-2xl ${lang === 'ar' ? 'left-4' : 'right-4'}`}
          >
            <Send size={24} className={lang === 'en' ? 'rotate-180' : ''} />
          </button>
          <div className={`absolute top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none group-focus-within:text-slate-900 transition-colors ${lang === 'ar' ? 'right-6' : 'left-6'}`}>
            <Sparkles size={24} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatView;
